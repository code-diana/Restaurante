package com.restaurant.restaurantbackend.services;

import com.restaurant.restaurantbackend.model.AdminModel;
import com.restaurant.restaurantbackend.repository.IAdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

@Service
public class AdminService {
    @Autowired
    IAdminRepository adminRepository;

    public ArrayList<AdminModel> getUsers(){
        return (ArrayList<AdminModel>) adminRepository.findAll();
    }

    public AdminModel saveUser(AdminModel user){
        return adminRepository.save(user);
    }

    public Optional<AdminModel> getById(Long id){
        return adminRepository.findById(id);
    }

    public AdminModel updateById(AdminModel request,Long id){
        AdminModel user = adminRepository.findById(id).get();

        user.setUserName(request.getUserName());
        user.setPass(request.getPass());

        return user;
    }

    public Boolean deleteUser (Long id){
        try{
            adminRepository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    }
}
