package com.restaurant.restaurantbackend.controller;

import com.restaurant.restaurantbackend.model.AdminModel;
import com.restaurant.restaurantbackend.services.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Optional;

@RestController
public class AdminController {
    @Autowired
    private AdminService adminService;

    @GetMapping
    public ArrayList<AdminModel> getUsers(){return this.adminService.getUsers();}

    @PostMapping
    public AdminModel saveUser(AdminModel user) {
        return this.adminService.saveUser(user);
    }

    @GetMapping(path = "/{id}")
    public Optional<AdminModel> getAdminById(@PathVariable("id") Long id){
        return this.adminService.getById(id);
    }

    @PutMapping(path = "/{id}")
    public AdminModel updateAdminById(@RequestBody AdminModel request, @PathVariable("id") Long id){
        return this.adminService.updateById(request, id);
    }

    @DeleteMapping(path = "/{id}")
    public String deleteAdminById(@PathVariable("id") Long id){
        boolean ok= this.adminService.deleteUser(id);

        if (ok){
            return "User with id "+ id + "deleted!";
        }
        else{
            return "Error, we have a problem and can't delete the user with id " + id;
        }
    }
}
